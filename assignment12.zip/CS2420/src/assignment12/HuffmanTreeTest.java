package assignment12;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class HuffmanTreeTest
{
    HuffmanTree t = new HuffmanTree();

    @Before
    public void setUp ()
    {
    }

    @Test
    public void testCompareTo ()
    {
        //test to be sure that the tree is being created in a way the ensures the left is smaller than the right. 
    }
    @Test
    public void testCreateTree ()
    {
        //
        
    }
    @Test
    public void testGetCode ()
    {
        fail("Not yet implemented");
    }
}
