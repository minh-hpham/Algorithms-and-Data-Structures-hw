package assignment13;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class representation of an airport. This is a vertex in a graph.
 * 
 * @author Sara Adamson
 */
public class Airport
{
    // airports have a name.
    private String name;

    // weight represents the value to get to that airport.
    private Double weight;

    // the airport taken to get here.
    private Airport cameFrom;

    // if true the airport has been visited
    private boolean visited;

    // TODO: should airports have a list of flights that are incoming and outgoing?
    private HashMap outgoingFlights;
    
    // list of neighbors
    private ArrayList<Airport> neighbors;

    public Airport (String name, HashMap outgoingFlights)
    {
        this.name = name;
        visited = false;
        cameFrom = null;
        weight = Double.MAX_VALUE;
        this.outgoingFlights = outgoingFlights;
    }
    

    public Airport (String name)
    {
        this(name, null);
    }

    public Airport getCameFrom ()
    {
        return cameFrom;
    }

    public void setCameFrom (Airport cameFrom)
    {
        this.cameFrom = cameFrom;
    }

    public boolean isVisited ()
    {
        return visited;
    }

    public void setVisited (boolean visited)
    {
        this.visited = visited;
    }

    public HashMap getOutgoingFlights ()
    {
        return outgoingFlights;
    }

    public void setOutgoingFlights (HashMap outgoingFlights)
    {
        this.outgoingFlights = outgoingFlights;
    }

    public String getName ()
    {
        return name;
    }

    public Double getWeight ()
    {
        return weight;
    }

    public void setWeight (Double weight)
    {
        this.weight = weight;
    }

    /**
     * Update the weight and cameFrome variables of this node
     */
    public void update (double updatedWeight, Airport current)
    {
        this.cameFrom = current;
        this.weight = updatedWeight;
        
    }

    /**
     * @return 
     */
    public ArrayList<Airport> getNeighbors ()
    {
        // TODO Auto-generated method stub
        return neighbors;
    }
    
    public void addNeigbor(Airport neighbor)
    {
    	this.neighbors.add(neighbor);
    }

}
