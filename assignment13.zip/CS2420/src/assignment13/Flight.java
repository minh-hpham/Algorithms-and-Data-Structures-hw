package assignment13;

import java.util.ArrayList;

/**
 * Class representation of a flight. This is an edge in a graph
 * 
 * @author Sara Adamson
 */
public class Flight
{
    // flights have a cost
    double cost;
    // a distance
    double distance;
    // a time
    double time;
    // may be canceled a 1 represents a canceled flight, and a 0 represents a flight that has not been canceled.
    int canceled;
    // may be delayed
    double delay;// TODO: how is this represented?
    // the value the user is using to search for a flight.
    double weight;
    // an origin airport
    Airport origin;
    // and a destination airport
    Airport destination;
    // and a carrier
    ArrayList<String> carriers = new ArrayList<>();;

    // Order from files: ORIG,DEST,CARR,DELAY,CANCE,TIME,DIST,COST
    public Flight (Airport origin, Airport destination, String carrier, double delay, int canceled, double time,
            double distance, double cost)
    {
        this.origin = origin;
        this.destination = destination;
        this.carriers.add(carrier);
        this.delay = delay;
        this.canceled = canceled;
        this.time = time;
        this.distance = distance;
        this.cost = cost;
        weight = 0;
    }

    /**
     * update this flight if the HashMap flights contains duplicates
     */
    public void updateFlight (double delay, int canceled, double time, double distance, double cost, String carrier)
    {
        this.delay = (this.delay + delay) / 2;
        this.canceled = (this.canceled + canceled) / 2;
        this.time = (this.time + time) / 2;
        this.distance = (this.distance) / 2;
        this.cost = (this.cost + cost) / 2;
        this.carriers.add(carrier);
    }

    public double getCost ()
    {
        return cost;
    }

    public void setCost (double cost)
    {
        this.cost = cost;
    }

    public double getDistance ()
    {
        return distance;
    }

    public void setDistance (double distance)
    {
        this.distance = distance;
    }

    public double getTime ()
    {
        return time;
    }

    public void setTime (double time)
    {
        this.time = time;
    }

    public int getCanceled ()
    {
        return canceled;
    }

    public void setCanceled (int canceled)
    {
        this.canceled = canceled;
    }

    public double getDelay ()
    {
        return delay;
    }

    public void setDelay (double delay)
    {
        this.delay = delay;
    }

    public Airport getOrigin ()
    {
        return origin;
    }

    public void setOrigin (Airport origin)
    {
        this.origin = origin;
    }

    public Airport getDestination ()
    {
        return destination;
    }

    public void setDestination (Airport destination)
    {
        this.destination = destination;
    }

    public ArrayList<String> getCarriers ()
    {
        return carriers;
    }

    public void setCarriers (ArrayList<String> carrier)
    {
        this.carriers = carrier;
    }

    public void setWeight (double weight)
    {
        this.weight = weight;
    }

	public Double getWeight()
	{
		return weight;
	}
}
